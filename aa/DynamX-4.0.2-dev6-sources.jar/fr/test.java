package fr;

public class test
{
    private static final int radiusY = 3;//3
    private static final int radiusYHalf = 1;//1
    private static final int radiusH = 7;//7
    private static final int squareRadiusH = radiusH * radiusH;
    private static final int radiusHHalf = 3;//3

    public static void main(String[] args) {
        int cx = 176;
        int cy = 1;
        int cz = 440;
        for (int i = 0; i < radiusY; i++) { //TODO DEPENDS ON SPEED ?
            for (int j = 0; j < squareRadiusH; j++) {
                int dx = (j % radiusH) - radiusHHalf;
                int dz = (j / radiusH) - radiusHHalf;
                int y = cy + i - radiusYHalf;
                int x = cx + dx;
                int z = cz + dz;

                System.out.println("Y " + (y - cy + radiusYHalf));
                System.out.println("get " + ((x - cx + radiusHHalf) + (z - cz + radiusHHalf) * radiusH));
            }
        }
        System.out.println("===");
        System.out.println((175 - 176 + 3) + (436 - 440 + 3) * 7);
    }
}

// dx = -1 = 2
// cz = -4 = -1
