package fr.dynamx.utils.optimization;

import javax.vecmath.Vector3f;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Optimizes memory usage of Vector3f
 */
public class ObjVector3f
{
    private static final AtomicInteger count0 = new AtomicInteger(0), count1 = new AtomicInteger(0);
    public static final Vector3f ZEROS = new Vector3f(0, 0, 0);
    public static final Vector3f ONES = new Vector3f(1, 1, 1);

    public static Vector3f get(float x, float y, float z) {
        if(x == 0 && y == 0 && z == 0) {
            count0.incrementAndGet();
            return ZEROS;
        }
        if(x == 1 && y == 1 && z == 1) {
            count1.incrementAndGet();
            return ONES;
        }
        return new Vector3f(x, y, z);
    }
}
